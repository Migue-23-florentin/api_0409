<?php

namespace App\Helpers;

use Psr\Http\Message\ResponseInterface as Response;

class ResponseHelper
{
    private $response;

    public function __construct(Response $response)
    {
        $this->response = $response;
    }

    public function respondWithJson($data, int $status = 200, string $message = ''): Response
    {
        $responseBody = [
            'status' => $status < 400 ? 'success' : 'error',
            'data' => $data
        ];

        if (!empty($message)) {
            $responseBody['message'] = $message;
        }

        $this->response->getBody()->write(json_encode($responseBody));
        return $this->response
            ->withHeader('Content-Type', 'application/json')
            ->withStatus($status);
    }

    public function respondWithError(string $message, int $status = 400): Response
    {
        return $this->respondWithJson(null, $status, $message);
    }
}