<?php

use Slim\Factory\AppFactory;
use App\Services\LoggerService;
use App\Config\DatabaseConnection;
use App\Controllers\AuthController;
use App\Controllers\CursosController;
use App\Controllers\PerfilController;
use App\Middleware\JwtMiddleware;
use App\Middleware\ValidationMiddleware;

require __DIR__ . '/vendor/autoload.php';

$config = require __DIR__ . '/src/Config/config.php';

// Inicializar el logger
$loggerService = new LoggerService();
$logger = $loggerService->getLogger();

// Inicializar la conexión a la base de datos
$dbConnection = DatabaseConnection::getInstance($config, $logger);
$db = $dbConnection->getConnection();

/**
 * Inicializa una aplicación Slim con middleware para parseo de cuerpos JSON, manejo de CORS, autenticación JWT,
 * caché simple en memoria, y gestión de errores. Define rutas para perfiles, cursos, autenticación y registro.
 */
$app = AppFactory::create();

// Middleware para parsear el cuerpo de la solicitud JSON
$app->addBodyParsingMiddleware();

// Middleware para manejar CORS si es necesario
$app->add(function ($request, $handler) {
    $response = $handler->handle($request);
    return $response
        ->withHeader('Access-Control-Allow-Origin', '*')
        ->withHeader('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Accept, Origin, Authorization')
        ->withHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
});

// Cache simple en memoria
$cache = [];

// Middleware JWT para las rutas protegidas
$app->group('', function ($group) use ($db, $logger, $cache) {
    $group->group('/perfil', function ($group) use ($db, $logger, $cache) {
      $group->get('', [new PerfilController($db, $logger, $cache), 'obtenerPerfil']);
      $group->put('', [PerfilController::class, 'actualizarPerfil'])->add(new ValidationMiddleware());
      $group->group('/cursos', function ($group) use ($db, $logger, $cache) {
        $group->get('', [new PerfilController($db, $logger, $cache), 'obtenerCursosInscritos']);
        $group->post('/inscribir', [PerfilController::class, 'inscribirEnCurso']);
      });
   });

})->add(new JwtMiddleware($config, $logger));

// Ruta para debugging
$app->get('/', function ($request, $response) {
  $response->getBody()->write('La API está activa');
  return $response;
});

// Ruta de autenticación
$app->post('/login', [new AuthController($db, $logger, $config), 'login'])
    ->add(new ValidationMiddleware());

// Ruta de registro
$app->post('/register', [new AuthController($db, $logger, $config), 'register'])
    ->add(new ValidationMiddleware());

// Ruta de actualizar token
$app->post('/refresh-token', [new AuthController($db, $logger, $config), 'refreshToken']);

// Rutas de cursos
$app->group('/cursos', function ($group) use ($db, $logger, $cache) {
  $group->get('/presenciales', [new CursosController($db, $logger), 'cursosDisponibles']);
  $group->get('/adistancia', [new CursosController($db, $logger), 'cursosDisponiblesADistancia']);
  $group->get('/emprendedurismo', [new CursosController($db, $logger), 'cursosEmprendedurismo']);
  $group->get('/generacion-digital', [new CursosController($db, $logger), 'cursosGeneracionDigital']);
  $group->get('/areas', [new CursosController($db, $logger), 'cursosAreas']);
  $group->post('/areas', [new CursosController($db, $logger), 'cursosPorArea']);
  $group->get('/{id}', [new CursosController($db, $logger), 'obtenerCursoPorId']);
});

// Captura todos los errores
$app->addErrorMiddleware(true, true, true);

$app->run();
